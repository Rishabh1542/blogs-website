<?php include("partials/header.php");

$search = $_GET['search'];
if ($_GET['maincategory'] == "ALL" && $_GET['subcategory'] == "ALL" && $_GET['search'] == "ALL")
  $sql = "select * from blog ORDER BY  id desc";
else if ($_GET['maincategory'] != "ALL" && $_GET['subcategory'] == "ALL" && $_GET['search'] == "ALL")
  $sql = "select * from blog where maincategory='" . $_GET['maincategory'] . "' ORDER BY id desc";
else if ($_GET['maincategory'] == "ALL" && $_GET['subcategory'] != "ALL" && $_GET['search'] == "ALL")
  echo $sql = "select * from blog where subbcategory='" . $_GET['subcategory'] . "' ORDER BY id desc";
else if ($_GET['maincategory'] != "ALL" && $_GET['subcategory'] != "ALL" && $_GET['search'] == "ALL")
  $sql = "select * from blog where maincategory='" . $_GET['maincategory'] . "' 
  and subbcategory='" . $_GET['subcategory'] . "' ORDER BY id desc";
else if ($_GET['maincategory'] == "ALL" && $_GET['subcategory'] == "ALL" && $_GET['search'] != "ALL")
  $sql = "select * from blog where maincategory='" . $_GET['search'] . "'
   or subbcategory='" . $_GET['search'] . "' or title like '%" . $_GET['search'] . "%' 
  or content like '%" . $_GET['search'] . "%' ORDER BY id desc ";
else
  $sql = "select * from blog where maincategory='" . $_GET['search'] . "' && subbcategory='" . $_GET['search'] . "' ORDER BY id desc";
$result = mysqli_query($conn, $sql);

?>


<title>DBLOG - BLOG</title>
<?php include("partials/navbar.php"); ?>

<div class="container">
  <div class="page-banner" style="height:100px;margin:10px">
    <div class="row justify-content-center align-items-center h-100">
      <div class="col-md-6">
        <nav aria-label="Breadcrumb">
          <ul class="breadcrumb justify-content-center py-0 bg-transparent">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active">Blog</li>
          </ul>
        </nav>
        <h1 class="text-center">Blog</h1>
      </div>
    </div>
  </div>
</div>
</header>

<div class="page-section">
  <div class="container">
    <div class="row">
      <div class="col-sm-10">
        <form action="./blog.php" method="get" class="form-search-blog">
          <div class="input-group">
            <div class="input-group-prepend">
              <select name="maincategory" class="custom-select bg-light">
                <option value="ALL">All mainCategories</option>
                <?php
                $q = "select * from maincategory order By id desc";
                $dataresult = mysqli_query($conn, $q);
                while ($row = $dataresult->fetch_assoc()) {
                  echo ("
                  <option value=" . $row['name'] . ">" . $row['name'] . "</option>
                  ");
                }


                ?>


              </select>

            </div>

            <div class="input-group-prepend">
              <select name="subcategory" class="custom-select bg-light">
                <option value="ALL">All subCategories</option>
                <?php
                $q = "select * from subcategory order By id desc";
                $dataresult = mysqli_query($conn, $q);
                while ($row = $dataresult->fetch_assoc()) {
                  echo ("
                  <option value=" . $row['name'] . ">" . $row['name'] . "</option>
                  ");
                }


                ?>


              </select>

            </div>



            <input type="text" class="form-control" name="search" value="<?php echo $search; ?>"
              placeholder="Enter keyword..">
          </div>

      </div>
      <div class="col-sm-2 text-sm-right">
        <button class="btn btn-secondary" type="submit">Filter <span class="mai-filter"></span></button>
      </div>
      </form>
    </div>


    <div class="row my-5">
      <?php
      if ($result = mysqli_query($conn, $sql)) {


        while ($row = $result->fetch_assoc()) {
          echo ("
  <div class='col-lg-4 py-3'>
  <div class='card-blog'>
    <div class='header'>
      <div class='post-thumb'>
      <button type='button' class='btn btn-primary position-relative'>
       " . $row['type'] . "
          
      </button>
      <a  href='blog-details.php?id=" . $row['id'] . "'>
    <img src='media/cover/" . $row['blog_image'] . "' style='width:100%;height:200px' alt=''>
        </a>
         
      </div>
    </div>
    <div class='body'>
      <h5 class='post-title'><a href='$baseurl/blog-details.php?id=" . $row['id'] . "'>" . $row['title'] . "</a></h5>
      <p class='post-title'>" . $row['maincategory'] . "/" . $row['subbcategory'] . "</p>
      <div class='post-date'>Posted:<span class='text text-primary '>" . $row['date'] . "</span></div>
    </div>
  </div>
</div>

  ");
        }
      }
      ?>

    </div>

    <nav aria-label="Page Navigation">
      <ul class="pagination justify-content-center">
        <li class="page-item disabled">
          <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
        </li>
        <li class="page-item"><a class="page-link" href="#">1</a></li>
        <li class="page-item active" aria-current="page">
          <a class="page-link" href="#">2 <span class="sr-only">(current)</span></a>
        </li>
        <li class="page-item"><a class="page-link" href="#">3</a></li>
        <li class="page-item">
          <a class="page-link" href="#">Next</a>
        </li>
      </ul>
    </nav>

  </div>
</div>
<?php include("partials/footer.php"); ?>