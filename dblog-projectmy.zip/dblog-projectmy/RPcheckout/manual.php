<!DOCTYPE html>
<html>
<head>
    <title>Razorpay Payment</title>
</head>
<body>

<div class="container mt-5 mb-5">
    <button id="rzp-button" class="btn btn-dark w-100">Pay Now</button>
</div>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>

<form name="razorpay_form" action="verify.php" method="post">
    <input type="hidden" name="razorpay_payment_id" id="razorpay_payment_id">
    <input type="hidden" name="razorpay_signature" id="razorpay_signature">
</form>

<script>
    // Assuming that you have defined the 'options' variable correctly
    var options = <?php echo $json; ?>; // Make sure $json is defined correctly

    options.handler = function(response) {
        document.getElementById('razorpay_payment_id').value = response.razorpay_payment_id;
        document.getElementById('razorpay_signature').value = response.razorpay_signature;
        document.razorpay_form.submit();
    };

    options.theme.image_padding = false;

    options.modal = {
        ondismiss: function() {
            console.log("This Code Runs When the popup is closed");
        },
        escape: true,
        backdropclose: false
    };

    var rzp = new Razorpay(options);

    document.getElementById('rzp-button').onclick = function(e) {
        e.preventDefault();
        rzp.open();
    };
</script>

</body>
</html>
