<?php include("partials/header.php"); 
if(isset($_POST['submit'])){
  $name=$_POST['name'];
  $email=$_POST['email'];
  $phone=$_POST['phone'];
  $subject=$_POST['subject'];
  $message=$_POST['message'];
  $sql="insert into contacts (`name`,`email`,`phone`,`subject`,`message`) values ('$name','$email','$phone','$subject','$message')";
  var_dump($sql);
  $result=mysqli_query($conn,$sql);
  if($result){
    echo "<script>alert('data inserted successfully ')</script>";
  }
  else{
    echo "<script>alert('data inserted not successfully ')</script>";
  }
}


?>

<title>DBLOG - contact</title>
<?php include("partials/navbar.php"); ?>

<div class="container">
  <div class="page-banner" style="height:100px;margin:10px">
    <div class="row justify-content-center align-items-center h-100">
      <div class="col-md-6">
        <nav aria-label="Breadcrumb">
          <ul class="breadcrumb justify-content-center py-0 bg-transparent">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active">Contact</li>
          </ul>
        </nav>
        <h1 class="text-center">Contact Us</h1>
      </div>
    </div>
  </div>
</div>
</header>

<div class="page-section">
  <div class="container">
    <div class="row text-center align-items-center">
      <div class="col-lg-4 py-3">
        <div class="display-4 text-center text-primary"><span class="mai-pin"></span></div>
        <p class="mb-3 font-weight-medium text-lg">Address</p>
        <p class="mb-0 text-secondary">city Dhampur,Dist Bijnor,UTTAR Pradesh,India</p>
      </div>
      <div class="col-lg-4 py-3">
        <div class="display-4 text-center text-primary"><span class="mai-call"></span></div>
        <p class="mb-3 font-weight-medium text-lg">Phone</p>
        <p class="mb-0"><a href="tel:6397358166" class="text-secondary">91+ 6397358166</a></p>

      </div>
      <div class="col-lg-4 py-3">
        <div class="display-4 text-center text-primary"><span class="mai-mail"></span></div>
        <p class="mb-3 font-weight-medium text-lg">Email Address</p>
        <p class="mb-0"><a href="mailto:rishabhkumar9067@gmail.com"
            class="text-secondary">rishabhkumar9067@gmail.com</a></p>

      </div>
    </div>
  </div>

  <div class="container-fluid mt-4">
    <div class="row">
      <div class="col-lg-6 mb-5 mb-lg-0">
        <form action="#" method="post" class="contact-form py-5 px-lg-5">
          <h2 class="mb-4 font-weight-medium text-secondary text-center">Get in touch</h2>
          <div class="row form-group">
            <div class="col-md-12 mb-3 mb-md-0">
              <label class="text-black" for="name">Name</label>
              <input type="text" id="name" name="name" class="form-control">
            </div>

          </div>

          <div class="row form-group">
            <div class="col-md-12">
              <label class="text-black" for="email">Email</label>
              <input type="email" id="email" name="email" class="form-control">
            </div>
          </div>

          <div class="row form-group">
            <div class="col-md-12">
              <label class="text-black" for="email">Phone</label>
              <input type="text" id="phone" name="phone" class="form-control">
            </div>
          </div>
          <div class="row form-group">

            <div class="col-md-12">
              <label class="text-black" for="subject">Subject</label>
              <input type="text" id="subject" name="subject" class="form-control">
            </div>
          </div>

          <div class="row form-group">
            <div class="col-md-12">
              <label class="text-black" for="message">Message</label>
              <textarea name="message" id="message" cols="30" rows="5" class="form-control"
                placeholder="Write your notes or questions here..."></textarea>
            </div>
          </div>

          <div class="row form-group mt-4">
            <div class="col-md-12">
              <input type="submit" name="submit" value="Send Message" class="btn btn-primary">
            </div>
          </div>
        </form>
      </div>
      <div class="col-lg-6 px-0 my-5">
        <div class="maps-container">
          <div id="google-maps">
            <div class="mapouter ">
              <div class="gmap_canvas"><iframe width="100%" height="500" id="gmap_canvas"
                  src="https://maps.google.com/maps?q=dhampur&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0"
                  scrolling="no" marginheight="0" marginwidth="0"></iframe><
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include("partials/footer.php"); ?>