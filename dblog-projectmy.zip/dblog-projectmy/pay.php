<?php
require "partials/header.php";
require "partials/navbar.php";
require "config.php";
require "razorpay-php/Razorpay.php";
if(!(isset($_GET['plan']))){
header("location:index.php");
die();
}

else if (!(isset($_SESSION['login']) and $_SESSION['login']==true)){
header("location:login.php");
die();
}
$username=$_SESSION['username'];

$sql="select * from users where username='$username'";

$result=mysqli_query($conn,$sql);
$row=$result->fetch_assoc();
$username=$row['name'];
$useremail=$row['email'];
$userphone=$row['phone'];


$plan=$_GET['plan'];
if($plan=="basic"){
  $finalamount= 199;  
}
else if($plan=="standard"){
    $finalamount=499;
}
else
$finalamount=1599;


// create the razorpay order
use Razorpay\Api\Api;
$api=new Api($keyId,$keySecret);



$orderData=[
    'receipt'=>time(),
    'amount'=>$finalamount *100,
    'currency'=>$displaycurrency,
    'payment_capture'=>1 //auto capture

];
$razorpayOrder = $api->order->create($orderData);
$razorpayOrderId=$razorpayOrder['id'];
$_SESSION['razorpay_order_id']=$razorpayOrderId;
$displayAmount=$amount=$orderData['amount'];

if($displaycurrency !== "INR"){
  $url="https://api.fixer.io/latest?symbols=$displaycurrency&base=INR";
  $exchange=json_decode(file_get_contents($url),true);
  $displayAmount=$exchange['rates'][$displaycurrency]*$amount/100;
}
$checkout='manual';
if(isset($_GET['checkout']) and in_array($_GET['checkout'],['automatic','manual'])){
  $checkout=$_GET['checkout'];
}
$data=[
  "key" =>$keyId,
  "amount" =>$amount,
  "name" =>"DBLOG",
  "description"=>"DBLOG WEBSITE",
  "image"=>"https://www.google.com/search?q=small+images&rlz=1C1UEAD_enIN1043IN1043&oq=small+images&gs_lcrp=EgZjaHJvbWUyBggAEEUYOTIHCAEQABiABDIHCAIQABiABDIHCAMQABiABDIHCAQQABiABDIHCAUQABiABDIHCAYQABiABDIHCAcQABiABDIHCAgQABiABDIHCAkQABiABNIBCDM3MzFqMGo3qAIAsAIA&sourceid=chrome&ie=UTF-8#vhid=UU-_q3DNArCdmM&vssid=l",
  "prefill"=>[
    "name" =>$username,

    "email"=>$useremail,
    "contact"=>$userphone,
  ],
  "theme"=>[
    "color"=>"#f37254"
  ],
  "order_id"=>$razorpayOrderId,
];

if ($displaycurrency !=='INR'){
  $data['display_currency']=$displaycurrency;
  $data['display_amount']=$displayAmount;
}
$json=json_encode($data);
require "RPcheckout/{$checkout}.php";
require "partials/footer.php";

?>