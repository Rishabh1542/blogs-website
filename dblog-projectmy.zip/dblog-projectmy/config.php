<?php
$keyId="rzp_test_5Wcs03c5unsC5o";
$keySecret="qgcX55mCB0OlrdBuMOOi32Od";
$displaycurrency="INR";
?>