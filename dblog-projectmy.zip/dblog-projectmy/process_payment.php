<?php
require 'razorpay-php/Razorpay.php';

// Initialize Razorpay with your API keys
$keySecret = 'qgcX55mCB0OlrdBuMOOi32Od';
$api = new Razorpay\Api\Api('', $keySecret);

// Fetch and parse the webhook payload
$webhookContent = file_get_contents("php://input");
$webhookData = json_decode($webhookContent, true);

// Verify the signature
$attributes = array(
    'razorpay_signature' => $_SERVER['HTTP_X_RAZORPAY_SIGNATURE'],
    'razorpay_payment_id' => $webhookData['payload']['payment']['entity']['id']
);
$webhookSecret = 'your_webhook_secret';
$api->utility->verifyPaymentSignature($attributes);

// Handle the webhook data (payment success/failure)
if ($webhookData['event'] === 'payment.authorized') {
    // Payment authorized
    // Handle your business logic here
} elseif ($webhookData['event'] === 'payment.failed') {
    // Payment failed
    // Handle your business logic here
}

// Send a response back to Razorpay
http_response_code(200);
?>
