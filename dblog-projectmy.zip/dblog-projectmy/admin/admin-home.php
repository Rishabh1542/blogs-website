<?php
require('../partials/header.php');

// authentication process code
if(!(isset($_SESSION['login']) and $_SESSION['login'])){
        header("location:../login.php");
        die();
    }
    else if($_SESSION['role'] == "user"){
        header("location:../profile.php");
        die();
    }
    // authentication process code end here
?>




<title>DBLOG | Admin-Home</title>
<?php require('../partials/navbar.php');?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-2">
<?php require('./sidebar.php');?>
        </div>
        <div class="col-md-10">
                <div class="row">
                <div class="col-md-4">
               <img src="../public/img/person/person_1.jpg" alt="" width="100%" height="95%">
                </div>
                <div class="col-md-8">
                        <h5 class="bg-primary text-center text-light">Admin profile</h5>
                        <table class="table table-bordered border-primary">
                                <tr>
                                        <th>NAME-:</th>
                                        <td>rishabh  chauhan</td>
                                </tr>
                                <tr>
                                        <th>USER-:</th>
                                        <td>admin</td>
                                </tr>
                                <tr>
                                        <th>PHONE-:</th>
                                        <td>6397358166</td>
                                </tr>
                                <tr>
                                        <th>Email-:</th>
                                        <td>rishabhchauhan@gmail.com</td>
                                </tr>
                                <tr>
                                        <th>ROLE-:</th>
                                        <td>Admin</td>
                                </tr>
                                <tr>
                                       <td colspan="2" class="text-center">
                                        <button><a class="btn btn-primary text-light" href="">update profile</a></button>
                                       </td>
                                </tr>
                        </table>
                </div>
                </div>
        </div>
</div>
</div>

<?php require('../partials/footer.php');?>