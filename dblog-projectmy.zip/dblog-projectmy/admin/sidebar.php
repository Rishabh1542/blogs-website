<div class="list-group  ">
  <a href="#" class="list-group-item list-group-item-action bg-primary text-light">
    menu
  </a>
  <a href="#" class="list-group-item list-group-item-action">Home</a>
  <a href="#" class="list-group-item list-group-item-action">All User</a>
  <a href="./admin-maincategory.php" class="list-group-item list-group-item-action">Maincategory</a>
  <a href="./admin.subcategory.php" class="list-group-item list-group-item-action">Subcategory</a>
  <a href="./admin-blog.php" class="list-group-item list-group-item-action">Blogs</a>
  <a href="./admin-contact.php" class="list-group-item list-group-item-action">Contacts</a>
  <a href="./admin-newsletter.php" class="list-group-item list-group-item-action">Newsletter</a>
  
</div>