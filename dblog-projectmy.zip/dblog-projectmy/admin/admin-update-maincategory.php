<?php
   require('../partials/header.php');

// authentication process code
if(!(isset($_SESSION['login']) and $_SESSION['login'])){
   header("location:../login.php");
   die();
}
else if($_SESSION['role'] == "user"){
   header("location:../profile.php");
   die();
}
// authentication process code end here


   $show=false;
   if(!isset($_GET['id'])){
      header("location:./admin-maincategory.php");
      die();

   }
   $id=$_GET['id'];
   if(isset($_POST['submit'])){
      $name=$_POST['name'];
      $sql="select * from maincategory where name='$name'";
      $result=mysqli_query($conn,$sql);
      if(mysqli_num_rows($result)==0){

         $upd="update  maincategory set `name` = '$name' where `id`='$id' ";
         var_dump($upd);
         $res=mysqli_query($conn,$upd);
         header("location:./admin-maincategory.php");
         die();
      }
      else{
         $show=true;
      }
   }
   else{

   $q="select * from maincategory where `id`='$id'";
   $res=mysqli_query($conn,$q);
if(mysqli_num_rows($res)==0){
   header("location:./admin-maincategory.php");
   die;

}
$row=$res->fetch_assoc();
$name=$row['name'];
var_dump($name);



   
}
   
   
   
   ?>



<title>DBLOG | Admin-addcategory</title>
<?php require('../partials/navbar.php');?>
<div class="container-fluid">
   <div class="row">
      <div class="col-md-2">
         <?php require('./sidebar.php');?>
      </div>
      <div class="col-md-10">
         <h5 class="bg-primary text-center text-light p-1 ">main category</h5>
        <?php
        if($show){
         echo" <div class='alert alert-danger text-center alert-dismissible fade show' role='alert'>
         <strong>maincateegory already exixts!</strong> 
         <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
       </div>";
        }
      
        ?>
       <form action="" method="post" enctype="multipart/form-data">
       <div class="mb-3">
         <label>Name-:</label>
         <input type="text" name="name"  id=""  required minlength="3" placeholder="Please enter the user name" class="form-control" value="<?php echo $name;?>">
</div>
<div class="mb-3 d-flex">
   <button type="reset" name="reset" class="btn btn-danger w-50">reset</button>
   <button type="submit" name="submit" class="btn btn-primary w-50">submit</button>
</div>
       </form>

      </div>
   </div>
</div><!--col-md-10-->
<?php require('../partials/footer.php');?>