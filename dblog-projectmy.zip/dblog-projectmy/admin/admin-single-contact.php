<?php
require('../partials/header.php');

// authentication process code
if(!(isset($_SESSION['login']) and $_SESSION['login'])){
        header("location:../login.php");
        die();
    }
    else if($_SESSION['role'] == "user"){
        header("location:../profile.php");
        die();
    }
    // authentication process code end here
?>
<?php
if(!isset($_GET['id'])){
    header("location:./admin-contact.php");
    die();
} 

$id=$_GET['id'];
$sql="select * from contacts where `id`='$id'";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)==0){
    header("location:./admin-contact.php");
    die();
} 
$row=$result->fetch_assoc();

$name=$row['name'];
$email=$row['email'];
$phone=$row['phone'];
$subject=$row['subject'];
$message=$row['message'];

?>



<title>DBLOG | Admin-Home</title>
<?php require('../partials/navbar.php');?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-2">
<?php require('./sidebar.php');?>
        </div>
        <div class="col-md-10">
              <h5 class="bg-primary text-center">Contact Us queries</h5>
              <table class="table table-responsive table-bordered">
                <tr>
                    <th>ID</th>
                    <td><?php echo $id?></td>
                </tr>
                <tr>
                    <th>NAME</th>
                    <td><?php echo $name?></td>
                </tr>
                <tr>
                    <th>EMAIL</th>
                    <td><?php echo $email?></td>
                </tr>
                <tr>
                    <th>PHONE</th>
                    <td><?php echo $phone?></td>
                </tr>
                <tr>
                    <th>SUBJECT</th>
                    <td><?php echo $subject?></td>
                </tr>
                <tr>
                    <th>MESSAGE</th>
                    <td><?php echo $message?></td>
                </tr>
              </table>

        </div>
</div>
</div>

<?php require('../partials/footer.php');?>