<?php require("../partials/header.php");

// authentication process code
if(!(isset($_SESSION['login']) and $_SESSION['login'])){
    header("location:../login.php");
    die();
}
else if($_SESSION['role'] == "user"){
    header("location:../profile.php");
    die();
}
// authentication process code end here
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $q = "select * from blog where `id` = '$id'";
    $result = mysqli_query($conn,$q);
    if(mysqli_num_rows($result)==0){
        header("location:admin-blog.php");
        die();
    }
    $row = $result->fetch_assoc();
    $title = $row['title'];
    $type = $row['type'];
    $content = $row['content'];
    $cover = $row['blog_image'];
    $date = $row['date'];
    $maincategory = $row['maincategory'];
    $subcategory = $row['subbcategory'];
    $id = $row['id'];
}
?>
<title>DBlog | Admin-Single-Blog</title>
<?php require("../partials/navbar.php"); ?>

<div class="container-fluid my-3">
    <div class="row">
        <div class="col-md-2">
            <?php require("./sidebar.php"); ?>
        </div>
        <div class="col-md-10">
            <h5 class="bg-primary text-center p-1 text-light">Blog <a href="admin-add-blog.php"><span class="material-symbols-outlined text-light float-right">add</span></a></h5>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <tr>
                        <th>Id</th>
                        <td><?php echo $id; ?></td>
                    </tr>
                    <tr>
                        <th>Title</th>
                        <td><?php echo $title; ?></td>
                    </tr>
                    <tr>
                        <th>Type</th>
                        <td><?php echo $type; ?></td>
                    </tr>
                    <tr>
                        <th>Cover</th>
                        <td><a href="<?php echo "$baseurl/media/cover/".$cover; ?>">
                        <img src="<?php echo "$baseurl/media/cover/".$cover; ?>" height="200px" width="300px" alt="">    
                    </a></td>
                    </tr>
                    <tr>
                        <th>Maincategory/Subcategory</th>
                        <td><?php echo("$maincategory/$subcategory"); ?></td>
                    </tr>
                    <tr>
                        <th>Content</th>
                        <td><?php echo $content; ?></td>
                    </tr>
                    <tr>
                        <th>Date</th>
                        <td><?php echo $date; ?></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                        <?php echo("<a href=./admin-update-blog.php?id=".$id." class='btn btn-primary w-100'>Update</a>"); ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require("../partials/footer.php"); ?>