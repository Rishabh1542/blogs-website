<?php
require('../partials/header.php');

// authentication process code
if(!(isset($_SESSION['login']) and $_SESSION['login'])){
   header("location:../login.php");
   die();
}
else if($_SESSION['role'] == "user"){
   header("location:../profile.php");
   die();
}
// authentication process code end here


?>
<?php
if (isset($_GET['type'])) {
   $id = $_GET['id'];
   $del = "delete from subcategory where `id`='$id'";
   $query = mysqli_query($conn, $del);
   header("location:./admin.subcategory.php");
   die();

}
$sql = "select * from subcategory";
$result = mysqli_query($conn, $sql);
?>

<title>DBLOG | Admin-subcategory</title>
<?php require('../partials/navbar.php'); ?>
<div class="container-fluid">
   <div class="row">
      <div class="col-md-2">
         <?php require('./sidebar.php'); ?>
      </div>
      <div class="col-md-10 subcategory">
         <h5 class="bg-primary text-center text-light p-1">sub category<a href="./admin-add-subcategory.php"><span
                  class="material-symbols-outlined text-light float-right">
                  add
               </span></a>
         </h5>
         <div class="table-responsive">
            <table class="table table-bordered">
               <tr>
                  <th>Id </th>
                  <th>name</th>
                  <th>maincategory</th>
                  <th></th>
                  <th></th>
               </tr>
               <?php
               while ($row = $result->fetch_assoc()) {
                  echo ("<tr>
<td>".$row['id']."</td>
<td>".$row['name']."</td>
<td>".$row['maincategory']."</td>
<td><a href='./admin-update-subcategory.php?id=".$row['id']."'><span class='material-symbols-outlined'>edit</span></a></td>
<td><a href='./admin.subcategory.php?type=delete&id=".$row['id']."'><span class='material-symbols-outlined'>delete_forever</span></a></td>
</tr>
");

               }
               ?>
            </table>
         </div>
      </div>
   </div>
</div>
<?php require('../partials/footer.php'); ?>