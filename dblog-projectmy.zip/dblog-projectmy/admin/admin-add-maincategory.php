<?php
require("../partials/header.php"); 

// authentication process code
if(!(isset($_SESSION['login']) and $_SESSION['login'])){
    header("location:../login.php");
    die();
}
else if($_SESSION['role'] == "user"){
    header("location:../profile.php");
    die();
}
// authentication process code end here

$show = false;
if ($_SERVER['REQUEST_METHOD']== "POST") {
    $name = $_POST['maincategory'];
    $q = "select * from maincategory where name = '$name'";
    $result = mysqli_query($conn, $q);
    if (mysqli_num_rows($result) == 0) {
        $q = "insert into maincategory(`name`) values('$name')";
        mysqli_query($conn, $q);
        header("location:./admin-maincategory.php");
        die();
    } else {
        $show = true;
    }
}
?>
<title>DBlog | Admin-Add-Maincategory</title>
<?php require("../partials/navbar.php"); ?>

<div class="container-fluid my-3">
    <div class="row">
        <div class="col-md-2">
            <?php require("./sidebar.php"); ?>
        </div>
        <div class="col-md-10">
            <h5 class="bg-primary text-center p-1 text-light">Maincategory</h5>
            <?php
            if ($show)
                echo "<div class='alert alert-danger text-center alert-dismissible fade show' role='alert'>
                Maincategory Already Exist!!!
                <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                  <span aria-hidden='true'>&times;</span>
                </button>
              </div>"
            ?>
            <form action="" method="post">
                <div class="mb-3">
                    <label>Name</label>
                    <input type="text" name="maincategory" required minlength="3" placeholder="Enter Maincategory Name : " class="form-control">
                </div>
                <div class="mb-3 d-flex">
                    <button type="reset" class="btn btn-danger w-50 btn-sm">Reset</button>
                    <button type="submit" class="btn btn-primary w-50 btn-sm">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require("../partials/footer.php"); ?>