<?php
require ("../partials/header.php");
// authentication process code
if(!(isset($_SESSION['login']) and $_SESSION['login'])){
    header("location:../login.php");
    die();
}
else if($_SESSION['role'] == "user"){
    header("location:../profile.php");
    die();
}
// authentication process code end here

$show = false;
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $allowedTags = '<p><strong><em><u><h1><h2><h3><h4><h5><h6><img><li><ol><ul><span><div><br><ins><del>';
    $title = $_POST['title'];
    $maincategory = $_POST['maincategory'];
    $subcategory = $_POST['subcategory'];
    $content = $_POST['content'];
    $type = $_POST['type'];
    $cover = "";
    if ($_FILES['cover']['name'] != "") {
        $cover = $_FILES['cover']['name'];
        move_uploaded_file($_FILES['cover']['tmp_name'], "../media/cover/" . $cover);
    }
    $q = "insert into blog(`title`,`blog_image`,`content`,`maincategory`,`subbcategory`,`type`) values('$title','$cover','$content','$maincategory','$subcategory','$type')";
    try {
        mysqli_query($conn, $q);
    } catch (mysqli_sql_exception $e) {
        echo ("<pre>");
        print_r($e);
        exit;
    }
    header("location:./admin-blog.php");
    die();
}

$q = "select * from maincategory";
$maincategoryResult = mysqli_query($conn, $q);
$q = "select * from subcategory";
$subcategoryResult = mysqli_query($conn, $q);
?>
<title>DBlog | Admin-Add-Blog</title>
<?php require("../partials/navbar.php"); ?>

<div class="container-fluid my-3">
    <div class="row">
        <div class="col-md-2">
            <?php require("./sidebar.php"); ?>
        </div>
        <div class="col-md-10">
            <h5 class="bg-primary text-center p-1 text-light">Blog</h5>
            <?php
            if ($show)
                echo "<div class='alert alert-danger text-center alert-dismissible fade show' role='alert'>
                Blog Already Exist!!!
                <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                  <span aria-hidden='true'>&times;</span>
                </button>
              </div>"
            ?>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label>Title</label>
                    <input type="text" name="title" required minlength="3" placeholder="Enter Blog Title : " class="form-control">
                </div>
                <div class="row mb-3">
                    <div class="col-md-3 col-sm-6">
                        <label>Maincategory</label>
                        <select name="maincategory" class="form-control">
                            <?php
                            while ($row = $maincategoryResult->fetch_assoc()) {
                                echo "<option value = '" . $row['name'] . "'>" . $row['name'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <label>Subcategory</label>
                        <select name="subcategory" class="form-control">
                            <?php
                            while ($row = $subcategoryResult->fetch_assoc()) {
                                echo "<option value = '" . $row['name'] . "'>" . $row['name'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <label>Type</label>
                        <select name="type" class="form-control">
                            <option value="Private">Private</option>
                            <option value="Public">Public</option>
                        </select>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <label>Cover Image</label>
                        <input type="file" name="cover" class="form-contorl">
                    </div>
                </div>
                <div class="mb-3">
                    <label>Content</label>
                    <textarea name="content" id="content" rows="5" class="form-control"></textarea>
                </div>
                <div class="mb-3 d-flex">
                    <button type="reset" class="btn btn-danger w-50 btn-sm">Reset</button>
                    <button type="submit" class="btn btn-primary w-50 btn-sm">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require("../partials/footer.php"); ?>