<?php
   require('../partials/header.php');

// authentication process code
if(!(isset($_SESSION['login']) and $_SESSION['login'])){
   header("location:../login.php");
   die();
}
else if($_SESSION['role'] == "user"){
   header("location:../profile.php");
   die();
}
// authentication process code end here



   $show=false;
   if(!isset($_GET['id'])){
      header("location:./admin.subcategory.php");
      die();

   }
   $id=$_GET['id'];
   if(isset($_POST['submit'])){
      $name=$_POST['name'];
      $maincategory=$_POST['maincategory'];
      $sql="select * from subcategory where name='$name' and maincategory='$maincategory'";
      $result=mysqli_query($conn,$sql);
      if(mysqli_num_rows($result)==0){

         $upd="update  subcategory set `name` = '$name',`maincategory`='$maincategory' where `id`='$id' ";
         var_dump($upd);
         $res=mysqli_query($conn,$upd);
         header("location:./admin.subcategory.php");
         die();
      }
      else{
         $show=true;
      }
   }
   else{

   $q="select * from subcategory where `id`='$id'";
   $res=mysqli_query($conn,$q);
if(mysqli_num_rows($res)==0){
   header("location:./admin.subcategory.php");
   die;

}
$row=$res->fetch_assoc();
$name=$row['name'];
$maincategory=$row['maincategory'];
// var_dump($name);

$q = "select * from maincategory";
$result = mysqli_query($conn, $q);

   
}
   
   
   
   ?>



<title>DBLOG | Admin-subcategory</title>
<?php require('../partials/navbar.php');?>
<div class="container-fluid">
   <div class="row">
      <div class="col-md-2">
         <?php require('./sidebar.php');?>
      </div>
      <div class="col-md-10">
         <h5 class="bg-primary text-center text-light p-1 ">sub category</h5>
        <?php
        if($show){
         echo" <div class='alert alert-danger text-center alert-dismissible fade show' role='alert'>
         <strong>subcateegory already exixts!</strong> 
         <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
       </div>";
        }
      
        ?>
       <form action="" method="post" enctype="multipart/form-data">
       <div class="row mb-3 ">
               <div class="col-md-9">
                  <label>Name-:</label>
                  <input type="text" name="name" id="" required minlength="3" placeholder="Please enter the user name" value="<?php echo $name;?>"
                     class="form-control">
               </div>
               <div class="col-md-3">
                  <label>maincategory</label>
                  <select name="maincategory" class="form-control">
                     <?php
                     while ($row = $result->fetch_assoc()){
                        if($maincategory==$row['name'])
                        echo "<option selected value =" . $row['name'] . ">" . $row['name'] . "</option>";
                    else
                    echo "<option value =" . $row['name'] . ">" . $row['name'] . "</option>";
                     }

                     ?>
                  </select>
               </div>
            </div>
<div class="mb-3 d-flex">
   <button type="reset" name="reset" class="btn btn-danger w-50">reset</button>
   <button type="submit" name="submit" class="btn btn-primary w-50">submit</button>
</div>
       </form>

      </div>
   </div>
</div><!--col-md-10-->
<?php require('../partials/footer.php');?>