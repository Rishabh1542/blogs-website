<?php require("../partials/header.php");

// authentication process code
if(!(isset($_SESSION['login']) and $_SESSION['login'])){
    header("location:../login.php");
    die();
}
else if($_SESSION['role'] == "user"){
    header("location:../profile.php");
    die();
}
// authentication process code end here
if(isset($_GET['type'])){
    $id = $_GET['id'];
    $q = "delete from blog where `id` = '$id'";
    mysqli_query($conn,$q);
    header("location:./admin-blog.php");
    die();
}

$q = "select * from blog order by id desc";
$result = mysqli_query($conn, $q);
?>
<title>DBlog | Admin-Blog</title>
<?php require("../partials/navbar.php"); ?>

<div class="container-fluid my-3">
    <div class="row">
        <div class="col-md-2">
            <?php require("./sidebar.php"); ?>
        </div>
        <div class="col-md-10">
            <h5 class="bg-primary text-center p-1 text-light">Blog <a href="admin-add-blog.php"><span class="material-symbols-outlined text-light float-right">add</span></a></h5>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <tr>
                        <th>Id</th>
                        <th>Title</th>
                        <th>Type</th>
                        <th>Maincategory</th>
                        <th>Subcategory</th>
                        <th>Cover</th>
                        <th></th>
                        <th></th>
                        <th></th>
                    </tr>
                    <?php
                    while ($row = $result->fetch_assoc()) {
                        echo ("<tr>
                                <td>".$row['id']."</td>
                                <td>".$row['title']."</td>
                                <td>".$row['type']."</td>
                                <td>".$row['maincategory']."</td>
                                <td>".$row['subbcategory']."</td>
                                <td><a href='$baseurl/media/cover/".$row['blog_image']."' target='_blank'><img src='$baseurl/media/cover/".$row['blog_image']."' height='70px' width='70px'></a></td>
                                <td><a href='./admin-update-blog.php?id=".$row['id']."'><span class='material-symbols-outlined'>edit</span></a></td>
                                <td><a href='./admin-single-blog.php?id=".$row['id']."'><span class='material-symbols-outlined'>visibility</span></a></td>
                                <td><a href='./admin-blog.php?type=delete&id=".$row['id']."'><span class='material-symbols-outlined'>delete_forever</span></a></td>
                            </tr>");
                    }
                    ?>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require("../partials/footer.php"); ?>