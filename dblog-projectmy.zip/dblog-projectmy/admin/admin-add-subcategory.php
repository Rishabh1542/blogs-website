<?php
require("../partials/header.php");


// authentication process code
if(!(isset($_SESSION['login']) and $_SESSION['login'])){
    header("location:../login.php");
    die();
}
else if($_SESSION['role'] == "user"){
    header("location:../profile.php");
    die();
}
// authentication process code end here

$show = false;
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $name = $_POST['subcategory'];
    $maincategory = $_POST['maincategory'];
    $q = "select * from subcategory where name = '$name'";
    $result = mysqli_query($conn, $q);
    if (mysqli_num_rows($result) == 0) {
        $q = "insert into subcategory(`name`,`maincategory`) values('$name','$maincategory')";
        mysqli_query($conn, $q);
        header("location:./admin.subcategory.php");
        die();
    } else {
        $show = true;
    }
}
$q = "select * from maincategory";
$result = mysqli_query($conn, $q);
?>
<title>DBlog | Admin-Add-Subcategory</title>
<?php require("../partials/navbar.php"); ?>

<div class="container-fluid my-3">
    <div class="row">
        <div class="col-md-2">
            <?php require("./sidebar.php"); ?>
        </div>
        <div class="col-md-10">
            <h5 class="bg-primary text-center p-1 text-light">Subcategory</h5>
            <?php
            if ($show)
                echo "<div class='alert alert-danger text-center alert-dismissible fade show' role='alert'>
                subcategory Already Exist!!!
                <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                  <span aria-hidden='true'>&times;</span>
                </button>
              </div>"
            ?>
            <form action="" method="post">
                <div class="row mb-3">
                    <div class="col-md-9">
                        <label>subcategory</label>
                        <input type="text" name="subcategory" required minlength="3" placeholder="Enter Subcategory Name : " class="form-control">
                    </div>
                    <div class="col-md-3">
                        <label>Maincategory</label>
                        <select name="maincategory" class="form-control">
                            <?php
                            while ($row = $result->fetch_assoc()) {
                                echo "<option value = '" . $row['name'] . "'>" . $row['name'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="mb-3 d-flex">
                    <button type="reset" class="btn btn-danger w-50 btn-sm">Reset</button>
                    <button type="submit" class="btn btn-primary w-50 btn-sm">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require("../partials/footer.php"); ?>