<?php
require("../partials/header.php");

// authentication process code
if(!(isset($_SESSION['login']) and $_SESSION['login'])){
    header("location:../login.php");
    die();
}
else if($_SESSION['role'] == "user"){
    header("location:../profile.php");
    die();
}
// authentication process code end here




$show = false;
if ($_GET['id']) {
    $id = $_GET['id'];
    $q = "select * from blog where `id` = '$id'";
    $blogResult = mysqli_query($conn, $q);
    if (mysqli_num_rows($blogResult) == 0) {
        header("location:./admin-blog.php");
        die();
    } else {
        $row = $blogResult->fetch_assoc();
        $title = $row['title'];
        $type = $row['type'];
        $maincategory = $row['maincategory'];
        $subcategory = $row['subbcategory'];
        $content = $row['content'];
        $cover = $row['blog_image'];
    }
}
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $title = $_POST['title'];
    $maincategory = $_POST['maincategory'];
    $subcategory = $_POST['subcategory'];
    $content = $_POST['content'];
    $type = $_POST['type'];
    if ($_FILES['cover']['name'] != "") {
        unlink('../media/users/$cover');
        $cover = $_FILES['cover']['name'];
        move_uploaded_file($_FILES['cover']['tmp_name'], "../media/cover/" . $cover);
    }
    $q = "update blog set `title` = '$title',`type` = '$type',`blog_image` = '$cover',`content` = '$content',`maincategory` = '$maincategory',`subbcategory` = '$subcategory' where `id` = '$id'";
    echo $q;
    try {
        mysqli_query($conn, $q);
    } catch (mysqli_sql_exception $e) {
        echo ("<pre>");
        print_r($e);
        exit;
    }
    header("location:./admin-blog.php");
    die();
}

$q = "select * from maincategory";
$maincategoryResult = mysqli_query($conn, $q);
$q = "select * from subcategory";
$subcategoryResult = mysqli_query($conn, $q);

?>
<title>DBlog | Admin-Add-Blog</title>
<?php require("../partials/navbar.php"); ?>

<div class="container-fluid my-3">
    <div class="row">
        <div class="col-md-2">
            <?php require("./sidebar.php"); ?>
        </div>
        <div class="col-md-10">
            <h5 class="bg-primary text-center p-1 text-light">Blog</h5>
            <?php
            if ($show)
                echo "<div class='alert alert-danger text-center alert-dismissible fade show' role='alert'>
                Blog Already Exist!!!
                <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                  <span aria-hidden='true'>&times;</span>
                </button>
              </div>"
            ?>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label>Title</label>
                    <input type="text" name="title" required minlength="3" placeholder="Enter Blog Title : " class="form-control" value="<?php echo $title; ?>">
                </div>
                <div class="row mb-3">
                    <div class="col-md-3 col-sm-6">
                        <label>Maincategory</label>
                        <select name="maincategory" class="form-control">
                            <?php
                            while ($row = $maincategoryResult->fetch_assoc()) {
                                if($row['name']==$maincategory)
                                echo "<option selected value = '" . $row['name'] . "'>" . $row['name'] . "</option>";
                                else
                                echo "<option value = '" . $row['name'] . "'>" . $row['name'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <label>Subcategory</label>
                        <select name="subcategory" class="form-control">
                            <?php
                            while ($row = $subcategoryResult->fetch_assoc()) {
                                if($row['name']==$subcategory)
                                echo "<option selected value = '" . $row['name'] . "'>" . $row['name'] . "</option>";
                                else
                                echo "<option value = '" . $row['name'] . "'>" . $row['name'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <label>Type</label>
                        <select name="type" class="form-control">
                            <?php
                                if($row['type']=="Private")
                                echo "<option value='Private' selected>Private</option>";
                                else
                                echo "<option value='Private'>Private</option>";
                                if($row['type']=="Public")
                                echo "<option value='Public' selected>Public</option>";
                                else
                                echo "<option value='Public'>Public</option>";
                            ?>
                        </select>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <label>Cover Image</label>
                        <input type="file" name="cover" class="form-contorl">
                    </div>
                </div>
                <div class="mb-3">
                    <label>Content</label>
                    <textarea name="content" id="content" rows="5" class="form-control"><?php echo $content; ?></textarea>
                </div>
                <div class="mb-3 d-flex">
                    <button type="reset" class="btn btn-danger w-50 btn-sm">Reset</button>
                    <button type="submit" class="btn btn-primary w-50 btn-sm">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require("../partials/footer.php"); ?>