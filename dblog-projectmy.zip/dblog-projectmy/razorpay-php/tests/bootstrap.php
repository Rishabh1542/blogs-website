<?php
$autoloader = require dirname(__DIR__) . '/vendor/autoload.php';