<?php
include "partials/header.php";

if(isset($_SESSION['username'])){
    $username="$_SESSION[username]";
    $sql="select * from users where `username`='$username'";
    
    $result=mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)==0){
        header("location:login.php");
        die();
        
    }
    
    else
    {
        $row=$result->fetch_assoc();
      
    }
}
else{
    header("location:login.php");
    die();
}



?>
<?php include "partials/navbar.php";?>
<title>DBLOG-About</title>
<div class="contaier-fluid">
<div class="container">
    <div class="row">
    <div class="col-md-5 bg-secondary" style="height:338px">
    <?php
    if($row['pic']){
        echo ("<img src='./media/users/".$row['pic']."' height='300px' width='100%'>");
    }
    else{
        echo ("<img src='./public/img/person/person_1.jpg' height='300px' width='100%'>"); 
    }
    ?>
    </div>
    <div class="col-md-7">

<table class="table table-bordered ">
    <tr>
        <th>Name</th>
        <td><?php echo $row['name'];?></td>
    </tr>
    <tr>
        <th>Email</th>
        <td><?php echo $row['email'];?></td>
    </tr>
    <tr>
        <th>Phone</th>
        <td><?php echo $row['phone'];?></td>
    </tr>
    <tr>
        <th>Subscription</th>
        <td><?php  $row['subscription']==0?print("no"):print("yes");?></td>
    </tr>
    <tr>
        <th>plan</th>
        <td><?php  $row['plan']==''?print("N/A"):print("yes");?></td>
    </tr>
    <tr>
        <th>Username</th>
        <td><?php echo $row['username'];?></td>
    </tr>
    <tr>
        <th>Role</th>
        <td><?php echo  $row['role'];?></td>
    </tr>

    <tr>
        
        <td colspan="2"><?php echo ("<a href='".$baseurl."/update-profile.php' class='btn btn-primary w-100 btn-sm'>Update</a>");?></td>
    </tr>


</table>

    </div>
</div>


</div>
</div>




<?php include "partials/footer.php";?>