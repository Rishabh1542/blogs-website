<?php
include "partials/header.php";

if (isset($_SESSION['username'])) {
  $username = "$_SESSION[username]";
  $sql = "select * from users where `username`='$username'";

  $result = mysqli_query($conn, $sql);
  if (mysqli_num_rows($result) == 0) {
    header("location:login.php");
    die();

  } else {
    $row = $result->fetch_assoc();
    $name = $row['name'];
    $email = $row['email'];
    $phone = $row['phone'];
    $pic = $row['pic'];
  }
} else {
  header("location:login.php");
  die();
}



$show = false;
$message = "";
if (isset($_POST['update'])) {


  $name = $_POST['name'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  if ($_FILES['pic']['name'] != "") {
    unlink("./media/users/$pic");
    $pic = $_FILES['pic']['name'];
    move_uploaded_file($_FILES['pic']['tmp_name'], "./media/users/" . $pic);
}
 

    $sql = "update users set `name`='$name',`email`='$email',`phone`='$phone',`pic`='$pic' where `username`='$username'";

    $result = mysqli_query($conn, $sql);
   if($_SESSION['role']=="admin"){
    header("location:./admin/admin-home.php");
   }else
    header("location:profile.php");
    die();
  }

 




?>
<title>Dblog - Login</title>
<?php include "partials/navbar.php"; ?>




<div class="container w-50">
  <h3 class="text-center">Update Profile Details</h3>
  <?php
  if ($show) {
    echo ("
        <div class='alert alert-warning alert-dismissible fade show' role='alert'>
  $message
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
        ");
  }

  ?>


  <form class="row g-3" method="post" enctype="multipart/form-data">
    <div class="col-md-12">
      <label for="name" class="form-label">Name</label>
      <input type="text" class="form-control" id="name" name="name" value="<?php echo $name ?>">
    </div>
    <div class="col-md-12">
      <label for="phone" class="form-label">Phone</label>
      <input type="text" class="form-control" id="phone" name="phone" value="<?php echo $phone ?>">
    </div>
    <div class="col-md-12">
      <label for="email" class="form-label">Email:</label>


      <input type="text" class="form-control" id="email" name="email" value="<?php echo $email ?>">

    </div>
    <div class="col-md-12">
      <label for="image" class="form-label">Image:</label>
      <input type="file" class="form-control" id="image" name="pic" value="<?php echo $pic ?>">
    </div>


    <div class="col-12 mb-3">
      <button class="btn btn-primary" name="update" type="submit">update form</button>
    </div>
  </form>


</div>

<?php
include "partials/footer.php";
?>