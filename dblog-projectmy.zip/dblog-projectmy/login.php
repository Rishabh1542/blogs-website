<?php
include "partials/header.php";
$show=false;
if(isset($_POST['login'])){
    $username=$_POST['username'];
    $password=$_POST['password'];
    $sql="select * from users where `username`='$username' and `password`='$password'";
    $result=mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)===0){
        $show=true;
      
    }
    else{
        $row=$result->fetch_assoc();
        $_SESSION['login']=true;
        $_SESSION['name']=$row['name'];
        $_SESSION['username']=$row['username'];
        $_SESSION['role']=$row['role'];
        if($row['role']== "admin"){
          header("location:admin/admin-home.php");
        }
      else{
        header("location:profile.php");
      }
        
    }
}


?>
<title>Dblog - Login</title>
<?php include "partials/navbar.php";?>


  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f5f5f7;
      margin: 0;
      padding: 0;
    }

    .login-page {
      max-width: 480px;
      margin: 0 auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 5px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      margin-top: 100px;
    }

    h2 {
      text-align: center;
      margin-bottom: 30px;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      font-weight: bold;
      margin-bottom: 5px;
    }

    .form-group input[type="text"],
    .form-group input[type="password"] {
      width: 100%;
      padding: 10px;
      font-size: 16px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }

    .form-group input[type="submit"] {
      width: 100%;
      padding: 10px;
      font-size: 16px;
      border-radius: 5px;
      border: none;
      background-color: #4caf50;
      color: #fff;
      cursor: pointer;
    }

    @media (max-width: 480px) {
      .container {
        max-width: 300px;
      }
    }
  </style>


  <div class="container login-page">
    <h3>Login Form</h3>
    <?php
    if($show){
        echo ("
        <div class='alert alert-warning alert-dismissible fade show' role='alert'>
  username and password not mtched;
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
        ");
    }
    
    ?>  
    <form method="post" action="">
   
      <div class="form-group">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" placeholder="Enter your username">
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="Enter your password">
      </div>
      <div class="form-group">
        <input type="submit" name="login" value="Login">
      </div>
      <div class="d-flex justify-content-between">
       <a href="./signup.php">sign up</a>
       <a href="./forget-password1.php">Forget password</a>
      </div>
    </form>
  </div>

<?php
include "partials/footer.php";
?>
