<?php
include "partials/header.php";
$show=false;
$message="";
if (isset($_POST['submit_otp'])){
    if(isset($_SESSION['reset-password-username']))
    $username=$_SESSION['reset-password-username'];
    else
    $username="none";
   
    
    $sql="select * from users where `username`='$username' ";
    $result=mysqli_query($conn,$sql);
    if(mysqli_num_rows($result)===0){
        $show=true;
        $message="unauthorised";
      
    }
    else{
     $password=$_POST['password'];
     $cpassword=$_POST['cpassword'];
      if($password === $cpassword){
       $sql="update users set `password`='$password' where `username`='$username'";
       $result=mysqli_query($conn,$sql);
       unset($_SESSION['reset-password-username']);
       header("location:./login.php");
       die();
      }
      else{
        $how=true;
        $message="password and confirm password doesn't matched";
      }
      
      }
        
    }



?>
<title>Dblog - Forget Password</title>
<?php include "partials/navbar.php";?>


  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f5f5f7;
      margin: 0;
      padding: 0;
    }

    .login-page {
      max-width: 480px;
      margin: 0 auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 5px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      margin-top: 100px;
    }

    h2 {
      text-align: center;
      margin-bottom: 30px;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      font-weight: bold;
      margin-bottom: 5px;
    }

    .form-group input[type="text"],
    .form-group input[type="password"] {
      width: 100%;
      padding: 10px;
      font-size: 16px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }

    .form-group input[type="submit"] {
      width: 100%;
      padding: 10px;
      font-size: 16px;
      border-radius: 5px;
      border: none;
      background-color: #4caf50;
      color: #fff;
      cursor: pointer;
    }

    @media (max-width: 480px) {
      .container {
        max-width: 300px;
      }
    }
  </style>


  <div class="container login-page">
    <h3 class="bg-primary text-center">Forget Password</h3>
    <?php
    if($show){
        echo ("
        <div class='alert alert-warning alert-dismissible fade show' role='alert'>
  $message;
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
        ");
    }
    
    ?>  
    <form method="post" action="">
   
      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="Enter new password">
      </div>
      <div class="form-group">
        <label for="password">Confirm Password</label>
        <input type="password" id="cpassword" name="cpassword" placeholder="Enter confirm password">
      </div>
      <div class="form-group">
        <input type="submit" name="submit_otp" value="submit otp">
      </div>
      <div class="d-flex justify-content-between">
       <a href="./signup.php">sign up</a>
       <a href="">New User?</a>
      </div>
    </form>
  </div>

<?php
include "partials/footer.php";
?>
