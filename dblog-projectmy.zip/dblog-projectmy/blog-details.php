<?php include("partials/header.php");


if(isset($_GET['id'])){
  $id=$_GET['id'];
  $sql = "select * from blog  WHERE id='$id'";
  $result = mysqli_query($conn, $sql);

}
else{
  header("location:./blog.php");
  die();
}




?>
<?php
      $row=$result->fetch_assoc();
      $title=$row['title'];
      $maincategory=$row['maincategory'];
      $subcategory=$row['subbcategory'];
      $type=$row['type'];
      $image=$row['blog_image'];
      
      $content=$row['content'];
      $date=$row['date'];
      
      ?>

  <div class="page-section pt-5">
    <div class="container">
      <nav aria-label="Breadcrumb">
        <ul class="breadcrumb p-0 mb-0 bg-transparent">
          <li class="breadcrumb-item"><a href="./index.php">Home</a></li>
          <li class="breadcrumb-item"><a href="./blog.php">Blog</a></li>
          <li class="breadcrumb-item active">"<?php echo $title;  ?>"</li>
        </ul>
      </nav>
      


      <div class="row">
        <div class="col-lg-8">
          <div class="blog-single-wrap">
            <div class="header">
              <div class="post-thumb">
                <img src="./media/cover/<?php echo $image; ?>" height="300px" width="100px" alt="blog-image">
              </div>
              <div class="meta-header">
                <div class="post-author">
                  <div class="avatar">
                    <img src="./public/img/person/person_1.jpg" alt="" width="50px" height="100px">
                  </div>
                  by <a href="#"><?php echo $type; ?></a>
                </div>

                <div class="post-sharer">
                  <a href="#" class="btn social-facebook"><span class="mai-logo-facebook-f"></span></a>
                  <a href="#" class="btn social-twitter"><span class="mai-logo-twitter"></span></a>
                  <a href="#" class="btn social-linkedin"><span class="mai-logo-linkedin"></span></a>
                  <a href="#" class="btn"><span class="mai-mail"></span></a>
                </div>
              </div>
            </div>
            <h1 class="post-title"><?php echo $title; ?></h1>
            <div class="post-meta">
              <div class="post-date">
                <span class="icon">
                  <span class="mai-time-outline"></span>
                </span> <a href="#"><?php echo $date; ?></a>
              </div>
              <div class="post-comment-count ml-2">
                <span class="icon">
                  <span class="mai-chatbubbles-outline"></span>
                </span> <a href="#">4 Comments</a>
              </div>
            </div>
            <div class="post-content">
             <?php echo $content; ?>
            </div>
          </div>

          <div class="comment-form-wrap pt-5">
            <h2 class="mb-5">Leave a comment</h2>
            <form action="#" class="">
              <div class="form-row form-group">
                <div class="col-md-6">
                  <label for="name">Name *</label>
                  <input type="text" class="form-control" id="name">
                </div>
                <div class="col-md-6">
                  <label for="email">Email *</label>
                  <input type="email" class="form-control" id="email">
                </div>
              </div>
              <div class="form-group">
                <label for="website">Website</label>
                <input type="url" class="form-control" id="website">
              </div>
  
              <div class="form-group">
                <label for="message">Message</label>
                <textarea name="msg" id="message" cols="30" rows="8" class="form-control"></textarea>
              </div>
              <div class="form-group">
                <input type="submit" value="Post Comment" class="btn btn-primary">
              </div>
  
            </form>
          </div>

        </div>
        <div class="col-lg-4">
          <div class="widget">
            <!-- Widget search -->
            <div class="widget-box">
              <form action="blog.php" method="get" class="search-widget">
                <input type="text" name="search" class="form-control" placeholder="Enter keyword..">
                <input type="hidden" name="maincategory" value="ALL">
                <input type="hidden" name="subcategory" value="ALL">
                <button type="submit"  class="btn btn-primary btn-block">search</button>
              </form>
            </div>

            <!-- Widget Categories -->
            <div class="widget-box">
              <h4 class="widget-title">Main Category</h4>
              <div class="divider"></div>
              <?php
              $q="select * from maincategory ";
              $result=mysqli_query($conn,$q);
              while($row=$result->fetch_assoc()){
 echo ("
 <ul class='categories'>
                <li><a href='./blog.php?maincategory=".$row['name']."&subcategory=ALL&search=ALL'>".$row['name']."</a></li>
               
              </ul>
              
           
            ");
            }
           ?>  
            </div>
 <!-- Widget Categories -->
            <div class="widget-box">
              <h4 class="widget-title">sub Category</h4>
              <div class="divider"></div>
              <?php
              $q="select * from subcategory ";
              $result=mysqli_query($conn,$q);
              while($row=$result->fetch_assoc()){
 echo ("
 <ul class='categories'>
                <li><a href='./blog.php?subcategory=".$row['name']."&maincategory=ALL&search=ALL'>".$row['name']."</a></li>
               
              </ul>
              
           
            ");
            }
           ?>  
            </div>
            <!-- Widget recent post -->
            <div class="widget-box">
              <h4 class="widget-title">Related Post</h4>
              <div class="divider"></div>
<?php

 $q="select * from blog where subbcategory='$subcategory' and maincategory='$maincategory'";
$result=mysqli_query($conn,$q);
while($row=$result->fetch_assoc()){
  echo ("
   <div class='blog-item'>
                  <a class='post-thumb' href='$baseurl/blog-details.php?id=".$row['id']."'>
                    <img src='./media/cover/".$row['blog_image']."' style='height:70px;width:100px' alt='image not found'>
                  </a>
                  <div class='content'>
                    <h6 class='post-title'><a href='$baseurl/blog-details.php?id=".$row['id']."'>".$row['title']."</a></h6>
                    <div class='meta'>
                      <a href='#'><span class='mai-calendar'></span>".$date."</a>
                      <a href='#'><span class='mai-person'></span> ".$type."</a>
                      <a href='#'><span class='mai-chatbubbles'></span> 19</a>
                    </div>
                  </div>
              </div>
  ");
}
?>
             

            

             
            </div>

          

          </div>
        </div>
      </div>

    </div>
  </div>

  <?php include("partials/footer.php"); ?>