<?php
include "partials/header.php";
$show=false;
$message="";
if(isset($_POST['signup'])){

    $password=$_POST['password'];
    $confirm_password=$_POST['confirm_password'];
    if($password === $confirm_password){
        $name=$_POST['name'];

        $username=$_POST['username'];
        $email=$_POST['email'];
        $phone=$_POST['phone'];
       
        $sql="select * from users where `username`='$username'" ;
        $result=mysqli_query($conn,$sql);
        if(mysqli_num_rows($result)===1){
            $show=true;
            $message="username already taken";
        }
            
          
        
        else{

        
          $sql="insert into users(`name`,`username`,`email`,`phone`,`password`) values('$name','$username','$email','$phone','$password')";
                   
           $result=mysqli_query($conn,$sql);
           echo '<script language="javascript">';
           echo 'confirm(message successfully sent)';  //not showing an alert box.
           echo '</script>';
            header("location:login.php");
        }  
        
    }
    else{
        $show="true";
        $message="password and confirm password not matched";
    }
}


?>
<title>Dblog - Login</title>
<?php include "partials/navbar.php";?>


<style>
      body {
      font-family: Arial, sans-serif;
    }

    .container {
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
    }

    .row {
      display: flex;
      flex-wrap: wrap;
      margin-bottom: 20px;
    }

    .col {
      flex: 1;
      padding: 10px;
    }

    .col-2 {
      flex-basis: 50%;
    }

    label {
      display: block;
      font-weight: bold;
      margin-bottom: 5px;
    }

    input[type="text"],
    input[type="email"],
    input[type="password"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 10px;
    }

    input[type="submit"] {
      background-color: #4CAF50;
      color: white;
      padding: 10px 20px;
      border: none;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    input[type="submit"]:hover {
      background-color: #45a049;
    }

    @media screen and (max-width: 600px) {
      .col-2 {
        flex-basis: 100%;
      }
    }
    </style>

  <div class="container signup">
    <h3>sign up Form</h3>
    <?php
    if($show){
        echo ("
        <div class='alert alert-warning alert-dismissible fade show' role='alert'>
  $message
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>
        ");
    }
    
    ?>  
  
  
    <form method="post" action="">
      <div class="row">
        <div class="col col-2">
          <label for="first_name">Name:</label>
          <input type="text" id="first_name" name="name" required>
        </div>
        <div class="col col-2">
          <label for="last_name">Username:</label>
          <input type="text" id="last_name" name="username" required>
        </div>
      </div>
      <div class="row">
        <div class="col col-2">
          <label for="email">Email:</label>
          <input type="email" id="email" name="email" required>
        </div>
        <div class="col col-2">
          <label for="phone">Phone:</label>
          <input type="text" id="phone" name="phone" required>
        </div>
      </div>
      <div class="row">
        <div class="col col-2">
          <label for="password">Password:</label>
          <input type="password" id="password" name="password" required>
        </div>
        <div class="col col-2">
          <label for="confirm_password">Confirm Password:</label>
          <input type="password" id="confirm_password" name="confirm_password" required>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <input type="submit" name="signup" value="Sign Up">
        </div>
      </div>
      <a href="login.php">Already have an account?/login</a>
    </form>
  
  </div>

<?php
include "partials/footer.php";
?>
