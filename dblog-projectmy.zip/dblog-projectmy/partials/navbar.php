</head>

<body>

  <!-- Back to top button -->
  <div class="back-to-top"></div>

  <header>
    <nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top">
      <div class="container">
        <a href="<?php echo $baseurl ?>/index.php" class="navbar-brand">D<span class="text-primary">BLOG</span></a>

        <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarContent" aria-controls="navbarContent"
          aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="navbar-collapse collapse" id="navbarContent">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="<?php echo $baseurl ?>/index.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo $baseurl ?>/about.php">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo $baseurl ?>/service.php">Services</a>
            </li>
            <li class="nav-item">
              <a class="nav-link"
                href="<?php echo $baseurl ?>/blog.php?maincategory=ALL&subcategory=ALL&search=ALL">Blog</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo $baseurl ?>/contact.php">Contact</a>
            </li>
            
            <li class="nav-item">
              <?php
              if (isset($_SESSION['login']) and $_SESSION['login']) {
                echo ("
                <div class='dropdown'>
  <button class='btn btn-secondary dropdown-toggle' type='button' id='dropdownMenuButton1' data-bs-toggle='dropdown' aria-expanded='false'>
    " . $_SESSION['name'] . "
  </button>
  <ul class='dropdown-menu' aria-labelledby='dropdownMenuButton1' style='margin-right:10px;'>");
                if ($_SESSION['role'] == "admin")

                  echo ("<li><a class='dropdown-item' href='" . $baseurl . "/admin/admin-home.php'>profile</a></li>");
                else
                echo("<li><a class='dropdown-item' href='" . $baseurl . "/profile.php'>profile</a></li>");
                  echo ("
    <li><a class='dropdown-item' href='" . $baseurl . "/logout.php'>logout</a></li>
   
  </ul>
</div>
                ");

              } else
                echo ("<a class='nav-link' href='" . $baseurl . "/login.php'>Login</a>");


              ?>

            </li>


          </ul>
        </div>

      </div>
    </nav>