<?php
$show=false;
if(isset($_POST['submit'])){
  $email=$_POST['email'];
  $sql="select * from newsletter where `email`='$email'";
  $result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)==1){
  $show=true;
  $message="your email Address is already subscribed";
}
else{
$sql="insert into newsletter(`email`) values('$email')";
$result=mysqli_query($conn,$sql);
$show=true;
$message="Thanks to Share newsletter sevice !!!! Now we can send your email related to our new blogs !!!!";
}


}

?>




<footer class="page-footer mt-5 bg-image" style="background-image: url(public/img/world_pattern.svg);">
    <div class="container">
      <div class="row mb-5">
        <div class="col-lg-3 py-3">
          <h3>DBLOG</h3>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero amet, repellendus eius blanditiis in iusto eligendi iure.</p>

          <div class="social-media-button">
            <a href="#"><span class="mai-logo-facebook-f"></span></a>
            <a href="#"><span class="mai-logo-twitter"></span></a>
            <a href="#"><span class="mai-logo-google-plus-g"></span></a>
            <a href="#"><span class="mai-logo-instagram"></span></a>
            <a href="#"><span class="mai-logo-youtube"></span></a>
          </div>
        </div>
        <div class="col-lg-3 py-3">
          <h5>Company</h5>
          <ul class="footer-menu">
            <li><a href="#">About Us</a></li>
            <li><a href="#">Career</a></li>
            <li><a href="#">Advertise</a></li>
            <li><a href="#">Terms of Service</a></li>
            <li><a href="#">Help & Support</a></li>
          </ul>
        </div>
        <div class="col-lg-3 py-3">
          <h5>Contact Us</h5>
          <p>rishabh kumar dist bijnor,uttarpradesh,India</p>
          <a href="tel:6397358166" class="footer-link">6397358166</a>
          <a href="mailto:rishabhsisodiya973@gmail.com" class="footer-link">rishabhsisodiya973@gmail.com</a>
        </div>
        <div class="col-lg-3 py-3">
          <h5>Newsletter</h5>
          <p>Get updates, news or events on your mail.</p>
          <?php
          if($show){
            echo("<div class='alert alert-warning alert-dismissible fade show' role='alert'>
  $message;
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>");
          }
          ?>
          <form action="#" method="post">
            <input type="email" name="email" class="form-control" placeholder="Enter your email..">
            <button type="submit" name="submit" class="btn btn-success btn-block mt-2">Subscribe</button>
          </form>
        </div>
      </div>

      <p class="text-center" id="copyright">Copyright &copy; 2023. This template design and develop by <a href="https://google.com/" target="_blank">MACode ID</a></p>
    </div>
  </footer>

<script src="<?php echo $baseurl?>public/js/jquery-3.5.1.min.js"></script>

<script src="<?php echo $baseurl?>public/js/bootstrap.bundle.min.js"></script>

<script src="<?php echo $baseurl?>public/js/google-maps.js"></script>

<script src="<?php echo $baseurl?>public/vendor/wow/wow.min.js"></script>

<script src="<?php echo $baseurl?>public/js/theme.js"></script>
<script>
    tinymce.init({
      selector: 'textarea',
      plugins: 'anchor autolink charmap codesample emoticons image link lists media searchreplace table visualblocks wordcount checklist mediaembed casechange export formatpainter pageembed linkchecker a11ychecker tinymcespellchecker permanentpen powerpaste advtable advcode editimage tinycomments tableofcontents footnotes mergetags autocorrect typography inlinecss',
      toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat',
      tinycomments_mode: 'embedded',
      tinycomments_author: 'Author name',
      mergetags_list: [
        { value: 'First.Name', title: 'First Name' },
        { value: 'Email', title: 'Email' },
      ]
    });
  </script>
</body>
</html>