<?php
require 'razorpay-php/Razorpay.php';

// Initialize Razorpay with your API keys
$keyId = 'rzp_test_5Wcs03c5unsC5o';
$keySecret = 'qgcX55mCB0OlrdBuMOOi32Od';
$api = new Razorpay\Api\Api($keyId, $keySecret);

// Get payment data from the form
$amount = $_POST['amount'];
$name = $_POST['name'];
$email = $_POST['email'];

// Create a Razorpay order
$orderData = [
    'amount' => $amount,
    'currency' => 'INR',
    'receipt' => uniqid(),
    'payment_capture' => 1 // Auto-capture payment
];
$order = $api->order->create($orderData);

// Redirect to the Razorpay payment page
header('Location: ' . $order['short_url']);
exit;
?>
